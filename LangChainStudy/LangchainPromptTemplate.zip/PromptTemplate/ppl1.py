from langchain_core.prompts import PromptTemplate
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.prompts.pipeline import PipelinePromptTemplate
from langchain_google_genai import GoogleGenerativeAI
from langchain_core.prompts import FewShotPromptTemplate

full_template = """{suggest}

{example}

{start}
"""
full_prompt = PromptTemplate.from_template(full_template)

human = "{text}"

prompt = PromptTemplate.from_template(f"You are a helpful assistant that helps athlete to find his perfect meal. {human}")

example_template = """Here's an example of an Allergic foods:

Allergic foods: {example_1}
"""
example_prompt = PromptTemplate.from_template(example_template)

start_template = """!

{input}
"""
start_prompt = PromptTemplate.from_template(start_template)



input_prompts = [
    ("suggest", prompt),
    ("example", example_prompt),
    ("start", start_prompt),
]


pipeline_prompt = PipelinePromptTemplate(
    final_prompt=full_prompt, pipeline_prompts=input_prompts
)

print(pipeline_prompt.input_variables)

api_key = "AIzaSyAHPASr7lSxy-Dmpn0UUuFxMYnggJj7nLk"
llm = GoogleGenerativeAI(model="gemini-2.0-flash", google_api_key=api_key)

chain = pipeline_prompt| llm

result = chain.invoke({
        "text":"I am a 20 years old boy, with 70 kg weight and 175 cm height, what is the recommended mead?",
        "example_1":"chicken",
        "input":"Can I use this suggestions?"
})
print(result)