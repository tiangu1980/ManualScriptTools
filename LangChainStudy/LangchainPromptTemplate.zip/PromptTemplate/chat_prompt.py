# import langchain prompt template
from langchain_core.prompts import ChatPromptTemplate

prompt_template = ChatPromptTemplate([
    ("system", "You are a helpful assistant"),
    ("human", "Tell me a joke about {topic}")
])

msg = prompt_template.invoke({"topic": "cats"})

print(msg)