
from langchain_core.prompts import PromptTemplate
from langchain_core.prompts import FewShotPromptTemplate
from langchain_google_genai import GoogleGenerativeAI
examples = [
    {
        "question": "谁活得更久，穆罕默德·阿里还是艾伦·图灵？",
        "answer": """
这里需要后续提问吗：是的。
后续提问：穆罕默德·阿里去世时多大？
中间答案：穆罕默德·阿里去世时74岁。
后续提问：艾伦·图灵去世时多大？
中间答案：艾伦·图灵去世时41岁。
所以最终答案是：穆罕默德·阿里
""",
    },
    {
        "question": "Craigslist 的创始人是什么时候出生的？",
        "answer": """
这里需要后续提问吗：是的。
后续提问：Craigslist 的创始人是谁？
中间答案：Craigslist 是由克雷格·纽马克创办的。
后续提问：克雷格·纽马克是什么时候出生的？
中间答案：克雷格·纽马克出生于1952年12月6日。
所以最终答案是：1952年12月6日
""",
    },
    {
        "question": "乔治·华盛顿的外祖父是谁？",
        "answer": """
这里需要后续提问吗：是的。
后续提问：乔治·华盛顿的母亲是谁？
中间答案：乔治·华盛顿的母亲是玛丽·鲍尔·华盛顿。
后续提问：玛丽·鲍尔·华盛顿的父亲是谁？
中间答案：玛丽·鲍尔·华盛顿的父亲是约瑟夫·鲍尔。
所以最终答案是：约瑟夫·鲍尔
""",
    },
    {
        "question": "《大白鲨》和《皇家赌场》的导演是否来自同一个国家？",
        "answer": """
这里需要后续提问吗：是的。
后续提问：《大白鲨》的导演是谁？
中间答案：《大白鲨》的导演是史蒂文·斯皮尔伯格。
后续提问：史蒂文·斯皮尔伯格来自哪里？
中间答案：美国。
后续提问：《皇家赌场》的导演是谁？
中间答案：《皇家赌场》的导演是马丁·坎贝尔。
后续提问：马丁·坎贝尔来自哪里？
中间答案：新西兰。
所以最终答案是：不是
""",
    },
]

example_prompt = PromptTemplate.from_template("Question: {question}\n{answer}")

prompt = FewShotPromptTemplate(
    examples=examples,
    example_prompt=example_prompt,
    suffix="Question: {input}",
    input_variables=["input"],
)

user_input = "世界上最大的沙漠是什么?"
user_prompt = prompt.format(input=user_input)
print(user_prompt)

api_key = "AIzaSyAHPASr7lSxy-Dmpn0UUuFxMYnggJj7nLk"
llm = GoogleGenerativeAI(model="gemini-2.0-flash", google_api_key=api_key)

response = llm.predict(user_prompt)
print(response)