
from langchain_core.prompts import PromptTemplate
from langchain_core.prompts import FewShotPromptTemplate
from langchain_google_genai import GoogleGenerativeAI

examples = [
    {"text": "I love this product, it works perfectly!", "sentiment": "positive"},
    {"text": "This is the worst movie I've ever seen.", "sentiment": "negative"},
    {"text": "The package arrived on time.", "sentiment": "neutral"}
]

example_prompt = PromptTemplate(
    input_variables=["text", "sentiment"],
    template="评论: {text}\n情感: {sentiment}\n"
)

few_shot_prompt = FewShotPromptTemplate(
    examples=examples,
    example_prompt=example_prompt,
    prefix="请根据以下评论判断其情感倾向。\n",
    suffix="评论: {input}\n情感:",
    input_variables=["input"]
)

prompt = few_shot_prompt.format(input="The service was good, but nothing special.")

print(prompt)

api_key = "AIzaSyAHPASr7lSxy-Dmpn0UUuFxMYnggJj7nLk"
llm = GoogleGenerativeAI(model="gemini-2.0-flash", google_api_key=api_key, temperature=0.1)

response = llm.predict(prompt)
print(response)