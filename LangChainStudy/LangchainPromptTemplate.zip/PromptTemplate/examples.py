from langchain_core.prompts import PromptTemplate
from langchain_core.prompts import ChatPromptTemplate
from langchain_google_genai import GoogleGenerativeAI
from langchain_core.prompts import FewShotPromptTemplate
from langchain.schema import StrOutputParser
api_key = "AIzaSyAHPASr7lSxy-Dmpn0UUuFxMYnggJj7nLk"
llm = GoogleGenerativeAI(model="gemini-2.0-flash", google_api_key=api_key)

system = ("You are a helpful assistant that helps athlete to find his perfect meal.")
human = "{text}"

prompt = ChatPromptTemplate.from_messages([
    ("system",system),
    ("human",human)
])


msg = "I am a 20 years old boy, with 70 kg weight and 175 cm height, what is the recommended mead?"

gm_examples = [
    {"食物名称": "鸡肉", "是否过敏": "是"}
]
gm_example_prompt = PromptTemplate(
    input_variables=["食物名称", "是否过敏"],
    template="食物名称: {gm}\n{answer}"
)

few_shot_prompt = FewShotPromptTemplate(
    examples=gm_examples,
    example_prompt=gm_example_prompt,
    prefix="根据下面输入, 去除掉过敏的食物。\n",
    suffix="食物名称: {input}\n是否过敏:",
    input_variables=["input"]
)

# chain = ({"test": title_chain}
#          | RunnablePassthrough.assign(story=story_chain)
#          | RunnablePassthrough.assign(review=review_chain))

chain = prompt | llm

result = chain.invoke(
    {
        "text":msg
    }
)

print(result)