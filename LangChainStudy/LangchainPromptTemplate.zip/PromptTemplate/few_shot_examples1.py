
from langchain_core.prompts import PromptTemplate
from langchain_core.prompts import FewShotPromptTemplate
from langchain_google_genai import GoogleGenerativeAI
example_prompt = PromptTemplate(
    input_variables=["incorrect", "correct"],
    template="原句：{incorrect}\n改正：{correct}"
)

# 定义 few-shot 示例列表
examples = [
    {"incorrect": "She go to school every day.", "correct": "She goes to school every day."},
    {"incorrect": "He don't like eat vegetables.", "correct": "He doesn't like to eat vegetables."},
    {"incorrect": "They was very happy yesterday.", "correct": "They were very happy yesterday."}
]

prompt = FewShotPromptTemplate(
    examples=examples,
    example_prompt=example_prompt,
    suffix="原句：{input}\n改正 ",
    input_variables=["input"],
)

user_input = "I has a dog who like play with ball?"
user_prompt = prompt.format(input=user_input)

api_key = "AIzaSyAHPASr7lSxy-Dmpn0UUuFxMYnggJj7nLk"
llm = GoogleGenerativeAI(model="gemini-2.0-flash", google_api_key=api_key)

response = llm.predict(user_prompt)
print(response)